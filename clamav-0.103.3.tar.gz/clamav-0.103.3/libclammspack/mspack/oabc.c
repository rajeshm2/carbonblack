/* This file is part of libmspack.
 * © 2013 Intel Corporation
 *
 * libmspack is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License (LGPL) version 2.1
 *
 * For further details, see the file COPYING.LIB distributed with libmspack
 */

/* OAB compression implementation */

#include "system.h"
#include "oab.h"

struct msoab_compressor *
  mspack_create_oab_compressor(struct mspack_system *sys)
{
  /* todo */
  return NULL;
}

void mspack_destroy_oab_compressor(struct msoab_compressor *self) {
  /* todo */
}
