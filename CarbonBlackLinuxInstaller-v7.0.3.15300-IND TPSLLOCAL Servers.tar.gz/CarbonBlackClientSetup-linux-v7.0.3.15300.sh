#!/bin/bash
# Stores all important files in a tmp directory, then completely uninstalls all
# current versions of cbsensor installed. This will reduce the chance of
# conflicts in the future. When all versions of cbsensor are removed this
# installer will then install the subsystems of the cbsensor and restore the old
# files. If the files are from 6.1.x they will be restored as a zip file,
# otherwise they will be installed in place. Then the sensor will be started.
#
#Globals
###############################################################################
PKG_NAME=CarbonBlackClientSetup-linux-v7.0.3.15300.tgz
APP_DIR=/var/opt/carbonblack/response
LOGSDIR=$APP_DIR/log
LOG_FILE=$LOGSDIR/install.log
OLDLOGSDIR=/var/log/cb/sensor
PATH=$PATH:/sbin:/usr/sbin:/bin:/usr/bin
RUNNING_KERNEL=$(uname -r)
KERNEL_MAJOR_MINOR=$(echo "$RUNNING_KERNEL" | awk '{split($0,a,"."); print a[1]"."a[2]}')
USE_OLD_META_RPM=0
DATE=$(date)
INSTALLDIR=$(dirname $(realpath "$0"))
PKG_PATH=$INSTALLDIR/$PKG_NAME
PLATFORM_INSTALL_DIR=$INSTALLDIR/pkgs
TMPDIR=""

package_manager=""
PKG_MAN=""
PKG_EXTENSION=""
OS_ID=""

USE_EBPF=true

COMPONENTS=(cbsensor cbsysd cbebpf)

#OS specific stuff
OS_INSTALL=""
OS_REINSTALL=""
OS_DOWNGRADE=""
OS_UPGRADE=""

#Functions
###############################################################################
check_root() {
  if [ "$(whoami)" != "root" ]; then
    print "Please run the install again as root."
    exit 1
  fi
}

# ensure tmpdir meets PSec Advisory 1 criteria
#   ref:  https://confluence.carbonblack.local/display/PSEC/PSec+Advisory+1+-+Installer+File+Permissions
get_secure_tmpdir() {
  umask 0077

  RETRIES=10
  while : ; do

    # create & continue to success exit if criteria met
    TMPDIR=$(mktemp -d)
    if [[ $(stat -Lc  "%a %u %g" $TMPDIR) == "700 0 0" ]] ; then break; fi

    # anything else retry, error exit if no retries left
    (( RETRIES-- )); (( RETRIES > 0 )) || print_and_log "Secure installation temp dir:  FAILED -- Installation aborted" && exit 1;
  done

  rm -rf $TMPDIR
  print_and_log "Secure installation temp dir:  SUCCESS"
}

# Appends '## ' to a string and prints it to the console
print() {
  local string="$1"

  echo "## $string"
}

# Appends '## ' to a string and writes it to the log file
log() {
  local string="$1"

  echo "## $string" >> ${LOG_FILE}
}

# Appends '## ' to a string and prints it to the console, as well as writes to
# the log file
print_and_log() {
  local string="$1"

  print "$string"
  log "$string"
}

check_valid_version() {
  if version_lt "$KERNEL_MAJOR_MINOR" "4.4"; then
    if [ "$KERNEL_MAJOR_MINOR" != "3.10" ]; then
      print "Kernel version $KERNEL_MAJOR_MINOR not supported"
      exit 1
    else
      print "Will use kernel module"
    fi
  else
      print "Will use eBPF-based sensor"
  fi
}

set_tools() {
  if [ "$(command -v tar)" ]; then
    TAR=$(command -v tar)
  fi

  if [ "$(command -v rpm)" ]; then
    package_manager="rpm"
    PKG_MAN=$(command -v rpm)

    OS_INSTALL="-ivh --replacefiles"
    OS_REINSTALL="-ivh --force --replacefiles"
    OS_DOWNGRADE="-Uvh --oldpackage --replacefiles"
    OS_UPGRADE="-Uvh --replacefiles"

    REMOVE_PACKAGE() {
      $($PKG_MAN -q "$1" && $PKG_MAN -e --allmatches "$1")
    }

    QUERY_INSTALLED_VERSION() {
      retval=$($PKG_MAN -q --queryformat '%{version}' "$1" 2>/dev/null || echo "")
      retval="${retval//v/}"

      # return the version without the 'v'
      echo "$retval"
    }
    QUERY_NEW_VERSION() {
      retval=$($PKG_MAN -qp --queryformat '%{version}' "$1" 2>/dev/null)
      retval="${retval//v/}"

      # return the version without the 'v'
      echo "$retval"
    }
  fi

  if [ "$(command -v dpkg)" ]; then
    package_manager="dpkg"
    PKG_MAN=$(command -v dpkg)

    OS_INSTALL="-i --force-overwrite"
    OS_REINSTALL="-i --force-overwrite"
    OS_DOWNGRADE="-i --force-overwrite"
    OS_UPGRADE="-i --force-overwrite"

    REMOVE_PACKAGE() {
      $($PKG_MAN -s "$1" 2>/dev/null && $PKG_MAN --purge "$1")
    }

    QUERY_INSTALLED_VERSION() {
      retval=$(dpkg-query --showformat='$Version' --show "$1" 2>/dev/null || echo "")
      echo "$retval"
    }
    QUERY_NEW_VERSION() {
      retval=$(dpkg -f "$1" Version)
      echo "$retval"
    }
  fi

  print "Using $package_manager as package manager"
}

check_kernel_devel() {
  if [ "$USE_EBPF" == true ]; then
    if [ "$OS_ID" == "ubuntu" ]; then
      # do we have headers matching this kernel? 0 yes, 1 no
      dpkg -l | grep "linux-headers-$(uname -r)" > /dev/null

      if [ $? -eq 1 ]; then
        needed_pkg=$(dpkg --list | grep "linux-headers-$(uname -r)" | awk '{print $2}')
        print_and_log "The package $needed_pkg is not installed. Please install $needed_pkg."
      fi
    else
      kernel_devel=$(rpm -qa | grep kernel_devel)

      if [ "${kernel_devel}" -eq 1 ]; then
        print_and_log "The package 'kernel_devel' is not installed. Please install kernel-devel."
      fi
    fi
  fi
}

determine_os() {
  if [[ -e /etc/os-release ]]; then
    OS_ID=$(grep -w "ID" </etc/os-release | awk -F= '{print $2}' | tr -d '"' | tr -d '[:space:]')
  elif [[ -e /etc/redhat-release ]]; then
    OS_ID=$(cut -d" " -f1 /etc/redhat-release)
  elif [[ -e /etc/system-release ]]; then
    OS_ID=$(cut -d" " -f1 /etc/system-release)
  fi

  # Convert OS_ID to all lowercase
  OS_ID=${OS_ID,,}
}

set_options() {
  # If the kernel is 4.4 or later use eBPF.
  if version_lt "$KERNEL_MAJOR_MINOR" "4.4"; then
    COMPONENTS+=(cbkmod)
    USE_EBPF=false
  fi

  # If the platform is ubuntu then change the extension
  if [ "$OS_ID" == "ubuntu" ]; then
    PKG_EXTENSION="deb"
  else
    PKG_EXTENSION="rpm"
  fi
}

version_gt() {
  test "$(echo "$@" | tr " " "\n" | sort -V | head -n 1)" != "$1"
}

version_lt() {
  test "$(echo "$@" | tr " " "\n" | sort -rV | head -n 1)" != "$1"
}

version_ge() {
  test "$(echo "$@" | tr " " "\n" | sort -rV | head -n 1)" == "$1"
}

get_operation() {
  # Figure out the currently installed version and the new version to install
  # and if we already have the current version installed.
  oVersion=$(QUERY_INSTALLED_VERSION "$1")
  nVersion=$(QUERY_NEW_VERSION "${PLATFORM_INSTALL_DIR}"/"$1"*.${PKG_EXTENSION})

  # if no old version, then this is a clean install
  if [ "$oVersion" == "" ]; then
    op=${OS_INSTALL}
    op_txt="install"

    # If the new version is the same as the installed version we need a reinstall
  elif [ "$oVersion" == "$nVersion" ]; then
    op=${OS_REINSTALL}
    op_txt="reinstall"
    # If the installed version is older than the new version we need an upgrade
  elif version_lt "$oVersion" "$nVersion"; then
    op=${OS_UPGRADE}
    op_txt="upgrade"
    # If the new version is older than the installed version we need a downgrade
  else
    version_gt "$oVersion" "$nVersion"
    op=${OS_DOWNGRADE}
    op_txt="downgrade"
  fi

  if [[ "$oVersion" == "" ]]; then
    print_and_log "$op_txt $nVersion"
  else
    print_and_log "$op_txt $oVersion -> $nVersion"
  fi
}

# If there are no config files installed, look in the 6.1.x location and
# use those if they exist
copy_config_files() {
  OLD_APP_DIR=/var/lib/cb

  SENSOR_CONFIGFILE=config.ini
  if [ ! -e "$APP_DIR"/"$SENSOR_CONFIGFILE" ] && [ -e "$OLD_APP_DIR"/"$SENSOR_CONFIGFILE" ]; then
    mv "$OLD_APP_DIR"/"$SENSOR_CONFIGFILE" "$APP_DIR"/"$SENSOR_CONFIGFILE"
  fi

  CBDAEMON_CONFIGFILE=sensorsettings.ini
  if [ ! -e "$APP_DIR"/"$CBDAEMON_CONFIGFILE" ] && [ -e "$OLD_APP_DIR"/"$CBDAEMON_CONFIGFILE" ]; then
    mv "$OLD_APP_DIR"/"$CBDAEMON_CONFIGFILE" "$APP_DIR"/"$CBDAEMON_CONFIGFILE"
  fi
}

# Clean up after failed prior installations attempts that left duplicate RPMs in place.
# This only needs to be checked on rpm based systems, dpkg does not allow this to happen.
cleanup_duplicate_sensors() {
  print_and_log "Checking for duplicate sensors"

  for pkg in "${COMPONENTS[@]}"; do
    while [ $($PKG_MAN -q "$pkg" | wc -l) -gt 1 ]; do
      dup=$($PKG_MAN -q --queryformat '%{version} ' "$pkg" cbsensor | cut -f 1 -d' ')
      echo "Duplicate sensors detected"
      echo "Attempting to remove $pkg-$dup"
      ($PKG_MAN -e --nodeps "$pkg-$dup")
    done
  done

  print_and_log "############################################################################"
}

#Sets the operation for upgrade/downgrade/reinstall
perform_operation() {
  print_and_log "############################################################################"
  print_and_log "$DATE"
  print_and_log "Installing cbsensor from $PLATFORM_INSTALL_DIR"

  for pkg in "${COMPONENTS[@]}"; do
    # What operation should we perform on this package?
    # The default operation is to upgrade
    op="--upgrade"
    op_txt="upgrade"
    get_operation "$pkg"

    # Return value of rpm is the number of failed packages
    # dpkg a return value of 0 means the transaction was a success
    if ! ${PKG_MAN} ${op} "${PLATFORM_INSTALL_DIR}"/"${pkg}"*.${PKG_EXTENSION} | tee -a ${LOG_FILE}; then
      print_and_log "Installation of ${pkg} failed."
      exit 5
    fi
  done
}

# servers older than 6.2.2 will deploy the legacy meta rpm instead of the newer
# tgz file we will need to handle this case here
check_pkg() {
  if [[ ! -f ${PKG_PATH} ]]; then
    BASE_NAME=$(basename ${PKG_NAME} .tgz)
    PKG_NAME=${BASE_NAME}.rpm
    USE_OLD_META_RPM=1
    PKG_PATH=${INSTALLDIR}/${PKG_NAME}
  fi
}

add_daemon() {
  print_and_log "Adding daemon..."

  # workaround for systemd's "Access Denied" bug
  # https://superuser.com/questions/1125250/systemctl-access-denied-when-root
  systemctl daemon-reexec

  print_and_log "$(systemctl enable cbdaemon.service 2>&1)"
  if [ "$USE_EBPF" == true ]; then
    print_and_log "$(systemctl enable cbebpfdaemon.service 2>&1)"
  fi

  print_and_log "$(sh /etc/sysconfig/modules/cbresponse.modules 2>&1)"

  print_and_log "$(chmod 600 /var/opt/carbonblack/response 2>&1)"

  print_and_log "Starting daemon..."
  print_and_log "$(systemctl restart cbdaemon.service 2>&1)"
  if [ "$USE_EBPF" == true ]; then
    print_and_log "$(systemctl restart cbebpfdaemon.service 2>&1)"
  fi

  print_and_log "CB Response Sensor is now installed"
}

check_necessary_files() {
  if [[ ! -f "$PKG_PATH" ]]; then
    print_and_log "Error: Installation package is not present"
    exit 2
  fi

  if [[ ! (-f "$INSTALLDIR"/sensorsettings.ini) ]]; then
    print_and_log "Error: sensorsettings.ini file is not present"
    exit 2
  else
    cp "$INSTALLDIR"/sensorsettings.ini "$APP_DIR"
    chmod 640 "$APP_DIR"/sensorsettings.ini
  fi
}

check_meta_rpm() {
  # Make sure the older meta package is no longer present from previous installations
  set +e # If the RPM isn't installed, we expect to catch an error in rval. Don't abort on error.
  CB_RPM_UNIST=("cb-linux-sensor" "cb_package-UNIFIED_RPM")
  for val in "${CB_RPM_UNIST[@]}"; do
    ${RPM} -q "$val" >/dev/null 2>/dev/null
    rval=$?
    if [[ ${rval} -eq 0 ]]; then
      echo "## Remove old meta rpm: ${val}" | tee -a ${LOG_FILE}
      ${RPM} -e "$val" >>${LOG_FILE} 2>&1
      echo "############################################################################" | tee -a ${LOG_FILE}
    fi
  done
  set -e # Re-enable abort on error.
}

# Install using tarball or legacy meta RPM
extract_package() {
  print_and_log "Extracting package"
  mkdir -p "${PLATFORM_INSTALL_DIR}"
  if [[ ${USE_OLD_META_RPM} == 0 ]]; then
    rm -f "${INSTALLDIR}"/*.rpm # Remove any old RPMs first
    (${TAR} xvzf "${PKG_PATH}" -C "${PLATFORM_INSTALL_DIR}" | tee -a ${LOG_FILE})
  else
    (${RPM} -i "${PKG_NAME}" >>${LOG_FILE})
  fi

  if [ "${PIPESTATUS[0]}" -ne 0 ]; then
    print_and_log "install failed on package extraction"
    exit 1
  fi
}

# Exit on error
set -e

build_directory_structure() {

  print "Building directory structure"

  mkdir -p "$LOGSDIR"
  touch $LOG_FILE
  mkdir -p "$APP_DIR"/eventlogs/finalized
  mkdir -p "$APP_DIR"/pkgs
  mkdir -p "$APP_DIR"/store
}

cleanup() {
  print_and_log "Cleanup setup packages"
  rm -rf "${PLATFORM_INSTALL_DIR}"

  # 6.1.x and earlier versions of the sensor stored data in /var/lib/cb
  # Since we are upgrading to a new file structure, delete the old files.
  # Leaving it in place causes problems with future upgrades.
  # Downgrade from >= 6.2.x to 6.1.x or earlier is not supported.
  rm -rf /var/lib/cb
}

main() {
  check_root
  check_valid_version
  set_tools
  build_directory_structure
  copy_config_files
  get_secure_tmpdir
  check_pkg
  extract_package
  check_necessary_files
  determine_os
  set_options

  #dpkg does not allow multiple packages with same name
  if [ "$package_manager" == "rpm" ]; then
    cleanup_duplicate_sensors
  fi

  perform_operation
  add_daemon
}

main

trap cleanup EXIT
