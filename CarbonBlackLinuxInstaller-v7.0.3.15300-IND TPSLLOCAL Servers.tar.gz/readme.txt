CarbonBlackClientSetup.tgz Standalone Installer archive for group 'IND TPSLLOCAL Servers'
  Sensor will connect to: https://sensors.pretty-rhino.my.cbcloud.de:443

Extract the contents of this archive before running the installer!
